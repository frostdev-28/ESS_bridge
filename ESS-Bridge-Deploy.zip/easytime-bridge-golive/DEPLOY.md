# Deploying the EasyTime → ESS bridge on this PC

Target location: **`C:\Users\shaik.j\easytime-bridge-golive`**

## 1. Extract

Right-click `ESS-Bridge-Deploy.zip` → **Extract All…** → enter `C:\Users\shaik.j` → **Extract**.

Or in PowerShell:

```powershell
Expand-Archive -Path "$HOME\Downloads\ESS-Bridge-Deploy.zip" -DestinationPath C:\Users\shaik.j
```

Check that this file exists:

```
C:\Users\shaik.j\easytime-bridge-golive\easytime-bridge\manifest.json
```

Never move, rename or delete this folder afterwards: Chrome loads the extension from it on every
start. Do not put it under OneDrive, Desktop or Downloads.

## 2. Retire the old machine

On the previous VPN machine open `chrome://extensions` and **Remove** the EasyTime → ESS bridge.
Only one machine should run it.

## 3. Prerequisites

- VPN connected. Both open in Chrome: your EasyTime Pro address **and** `https://champ-hr.com`.
- Chrome **144 or newer** (`chrome://version`).
- A dedicated Chrome profile (e.g. "ESS bridge"), logged in to EasyTime Pro, ideally as a
  read-only user.
- The import token from the password manager (the same `EASYTIME_IMPORT_TOKEN` already set on
  Railway). Never paste it into chat or email.

## 4. Load the extension

1. In the bridge profile open `chrome://extensions`.
2. Turn on **Developer mode** (top right) and leave it on.
3. **Load unpacked** → select `C:\Users\shaik.j\easytime-bridge-golive\easytime-bridge`
   (the folder that contains `manifest.json`).
4. Puzzle-piece icon → pin **EasyTime → ESS**.
5. Chrome **Settings → System** → turn on **Continue running background apps when Google Chrome
   is closed**.

## 5. Configure

Click the bridge icon → **Settings**:

| Field | Value |
|---|---|
| EasyTime Pro address | Exactly as you open it, with port, no trailing slash |
| ESS portal address | `https://champ-hr.com` |
| Import token | Paste from the password manager |
| Everything else | Leave at defaults |

**Save** and click **Allow** when Chrome asks for access to both addresses.

## 6. Verify

1. **Test EasyTime** → data found, `page_size` works, newest-first **yes**, date filter **works**.
2. **Test ESS** → token accepted.
3. Within a few minutes the popup shows **Up to date**.
4. Use **Re-send dates** for the days since the old machine stopped, so nothing is missed
   (ESS skips duplicates).
5. ESS → **Admin Controls → Biometric → Device feed** lists the new batches with *Applied* counts.

## 7. Keep it running

- PC never sleeps (Power settings → Sleep: **Never** when plugged in).
- VPN set to reconnect automatically.
- Chrome running in the background (step 4.5).

Badge colours: **red** = VPN/ESS unreachable, **amber** = logged out of EasyTime. Both clear on
the next sync once fixed.

## Updating later

Replace files inside `C:\Users\shaik.j\easytime-bridge-golive\easytime-bridge`, then click the
**reload** icon on the bridge in `chrome://extensions`. Settings are kept.

## Remaining go-live items

See the *Still open* checklist in `README.md` (unknown employee codes, spot-check, recovery tests,
revoking the old handover token). Full extension manual: `easytime-bridge\README.md`.
To continue with Claude Code:

```powershell
cd C:\Users\shaik.j\easytime-bridge-golive; claude
```
